package com.product.globalmart.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.product.globalmart.entity.ProductEntity;

public interface ProductDAO extends CrudRepository<ProductEntity, Integer>{

	List<ProductEntity> findByProductType(String productType);
	
	List<ProductEntity> findByProductName(String productName);
	
}
