package com.product.globalmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalmartApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalmartApplication.class, args);
		
		System.out.println("Spring Boot Starter");
	}
}
